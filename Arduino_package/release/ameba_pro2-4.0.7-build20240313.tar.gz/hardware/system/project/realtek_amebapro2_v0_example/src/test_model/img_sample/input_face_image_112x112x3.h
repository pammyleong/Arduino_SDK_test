#ifndef TEST_FACE_DATA_H_
#define TEST_FACE_DATA_H_

extern const unsigned char test_face_112_112[];
extern int test_face_112_112_size;

#endif //TEST_FACE_DATA_H_

