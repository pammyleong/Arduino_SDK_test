#ifndef crypto_uint64_h
#define crypto_uint64_h

#include <stdint.h>

typedef uint64_t crypto_uint64;

#endif
