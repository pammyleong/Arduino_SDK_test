#ifndef WRITEALL_H
#define WRITEALL_H

extern int writeall(int, const void *, long long);

#endif
