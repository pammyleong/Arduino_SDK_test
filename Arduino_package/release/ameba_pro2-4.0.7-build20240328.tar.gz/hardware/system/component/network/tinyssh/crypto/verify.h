#ifndef _VERIFY_H____
#define _VERIFY_H____

extern int verify(const unsigned char *, const unsigned char *, long long);

#endif
