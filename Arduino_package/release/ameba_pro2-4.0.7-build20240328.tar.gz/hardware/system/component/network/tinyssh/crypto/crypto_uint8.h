#ifndef crypto_uint8_h
#define crypto_uint8_h

#include <stdint.h>

typedef uint8_t crypto_uint8;

#endif
