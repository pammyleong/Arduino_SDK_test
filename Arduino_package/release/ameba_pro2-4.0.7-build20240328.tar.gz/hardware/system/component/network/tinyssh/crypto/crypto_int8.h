#ifndef crypto_int8_h
#define crypto_int8_h

#include <stdint.h>

typedef int8_t crypto_int8;

#endif
