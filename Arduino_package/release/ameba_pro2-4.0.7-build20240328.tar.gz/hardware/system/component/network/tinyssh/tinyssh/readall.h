#ifndef _READALL_H____
#define _READALL_H____

extern int readall(int, void *, long long);

#endif
