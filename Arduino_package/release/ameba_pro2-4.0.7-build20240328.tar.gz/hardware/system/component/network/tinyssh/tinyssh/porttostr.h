#ifndef _PORTTOSTR_H____
#define _PORTTOSTR_H____

#define PORTTOSTR_LEN 6

extern char *porttostr(char *, const unsigned char *);

#endif
