#ifndef _CONNECTIONINFO_H____
#define _CONNECTIONINFO_H____

extern void connectioninfo(char *, char *, char *, char *);

#endif
