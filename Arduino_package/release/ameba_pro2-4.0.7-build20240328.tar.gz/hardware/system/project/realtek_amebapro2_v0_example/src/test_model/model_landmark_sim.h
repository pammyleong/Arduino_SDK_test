#ifndef MODEL_LANDMARK_SIM_H
#define MODEL_LANDMARK_SIM_H

#include "module_vipnn.h"

extern nnmodel_t lmsim_fwfs;

#endif /* MODEL_LANDMARK_SIM_H */