extern unsigned char examples_dog_975ms_wav[];
extern unsigned int examples_dog_975ms_wav_len;