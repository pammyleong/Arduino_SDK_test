#ifndef MODEL_MBNETSSD_H
#define MODEL_MBNETSSD_H

#include "module_vipnn.h"

extern nnmodel_t facedet_uint8;
extern nnmodel_t humandet_uint8;
extern nnmodel_t mbnetssd_fwfs;
#endif