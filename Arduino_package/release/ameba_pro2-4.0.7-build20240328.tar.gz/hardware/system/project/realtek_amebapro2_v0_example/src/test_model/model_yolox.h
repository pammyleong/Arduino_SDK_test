#ifndef _MODEL_YOLOX_H_
#define _MODEL_YOLOX_H_

#include "module_vipnn.h"

extern nnmodel_t yolox_fwfs;

#endif /* _MODEL_YOLOX_H_ */