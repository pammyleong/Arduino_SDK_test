/*
 *******************************************************************************
 * Copyright(c) 2021, Realtek Semiconductor Corporation. All rights reserved.
 *******************************************************************************
 */

#ifndef __ATCMD_BLE_GAP_IMPL_H__
#define __ATCMD_BLE_GAP_IMPL_H__

#ifdef __cplusplus
extern "C" {
#endif

int atcmd_bt_gap(int argc, char* argv[]);

#ifdef __cplusplus
}
#endif

#endif